using UnityEngine;

public class ShootableBox : MonoBehaviour
{
    public int CurrentHealth = 3;

    public void Damage(int damageAmount)
    {
        CurrentHealth -= damageAmount;

        if (CurrentHealth <= 0)
        {
            gameObject.SetActive(false);
        }
    }
}
